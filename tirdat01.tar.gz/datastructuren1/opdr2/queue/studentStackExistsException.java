/**
 * @author Paul Sohier
 **/
public class studentStackExistsException extends Exception
{

}
